@echo off

chcp 65001 >nul

net session >nul 2>&1

if %errorlevel% neq 0 (
    echo Requesting administrator permission...
    powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

title Elysia Installer

set "B64=%TEMP%\elysia-setup.b64"
set "PS1=%TEMP%\elysia-setup.ps1"

> "%B64%" echo -----BEGIN CERTIFICATE-----
>>"%B64%" echo 77u/IyAtKi0gY29kaW5nOiB1dGYtOCAtKi0KIyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09
>>"%B64%" echo PT09PT09PT09PT09PT0KIyAg5YyFMiDCtyDniLHojonkurrmoLwgKyDor63pn7Mg5LiA6ZSu5a6J6KOFCiMgIOWJjeaPkDog5bey
>>"%B64%" echo 6KOFIOWMhTEgKERlZXBTZWVrIEhhcm5lc3MpCiMgIOeUqOazlTog5Y+M5Ye7IGluc3RhbGwuYmF0IC0+IOiHquWKqOWujOaIkAoj
>>"%B64%" echo ICDljIXlkKs6IOeIseiOieS6uuagvOmihOiuviArIOesrOS4gOeJiOWjsOe6vyAoQ29zeVZvaWNlKQojID09PT09PT09PT09PT09
>>"%B64%" echo PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PQokRXJyb3JBY3Rpb25QcmVmZXJlbmNlID0gJ1N0
>>"%B64%" echo b3AnCiRDeWFuID0gJ0N5YW4nOyAkR3JlZW4gPSAnR3JlZW4nOyAkWWVsbG93ID0gJ1llbGxvdyc7ICRQaW5rID0gJ01hZ2VudGEn
>>"%B64%" echo CmZ1bmN0aW9uIFNheSgkbSwgJGMgPSAkQ3lhbikgeyBXcml0ZS1Ib3N0ICIgICRtIiAtRm9yZWdyb3VuZENvbG9yICRjIH0KCiMg
>>"%B64%" echo VVRGLTgg5pegIEJPTSDlhpnlhaU6IFBTNS4xIOeahCBBZGQtQ29udGVudCAtRW5jb2RpbmcgVVRGOCDkvJrmioogQk9NIOa3t+i/
>>"%B64%" echo m+W3suacieaWh+S7tiwKIyBZQU1MIOino+aekOWZqOWvueS4remXtOWGkuWHuuadpeeahCBCT00g5LiN5LiA5a6a5a655b+NIOKA
>>"%B64%" echo lOKAlCDnu5/kuIDor7vov5vmnaXov73liqDlho3nlKjml6AgQk9NIOWGmeWbngokc2NyaXB0OnV0ZjhOb0JvbSA9IE5ldy1PYmpl
>>"%B64%" echo Y3QgU3lzdGVtLlRleHQuVVRGOEVuY29kaW5nKCRmYWxzZSkKClNheSAn4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ
>>"%B64%" echo 4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ
>>"%B64%" echo 4pWQ4pWQJyAkUGluawpTYXkgJyAg54ix6I6J5biM6ZuFIMK3IOS6uuagvOS4juivremfs+WuieijhScgJFBpbmsKU2F5ICfilZDi
>>"%B64%" echo lZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDi
>>"%B64%" echo lZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZAnICRQaW5rClNheSAnJwoKJGRzaEhvbWUgPSBKb2luLVBhdGggJGVu
>>"%B64%" echo djpVU0VSUFJPRklMRSAnLmRzaCcKJHNjcmlwdERpciA9ICgkYXJnc1swXSAtcmVwbGFjZSAnIicsICcnKS5UcmltRW5kKCdcJykK
>>"%B64%" echo CiMgMS4g5qOA5p+lIERTSApTYXkgJ1sxLzNdIOajgOafpSBEZWVwU2VlayBIYXJuZXNzIC4uLicKJGRzaCA9IEdldC1Db21tYW5k
>>"%B64%" echo IGRzaCAtRXJyb3JBY3Rpb24gU2lsZW50bHlDb250aW51ZQppZiAoLW5vdCAkZHNoKSB7CiAgICBTYXkgJyAg5pyq5qOA5rWL5Yiw
>>"%B64%" echo IERTSCwg6K+35YWI5a6J6KOFIOWMhTEgKOaguOW/g+WMhSkhJyAkWWVsbG93CiAgICBSZWFkLUhvc3QgJ+aMieWbnui9pumAgOWH
>>"%B64%" echo uic7IGV4aXQgMQp9ClNheSAnICBPSycgJEdyZWVuCgojIDIuIOWuieijheS6uuagvOmihOiuvgpTYXkgJ1syLzNdIOWuieijheeI
>>"%B64%" echo seiOieS6uuagvCAuLi4nCiRwcmVzZXREaXIgPSBKb2luLVBhdGggJGRzaEhvbWUgJy5hZ2VudC1wcmVzZXRzXGVseXNpYScKTmV3
>>"%B64%" echo LUl0ZW0gLUl0ZW1UeXBlIERpcmVjdG9yeSAtUGF0aCAkcHJlc2V0RGlyIC1Gb3JjZSB8IE91dC1OdWxsCiRwcmVzZXRTcmMgPSBK
>>"%B64%" echo b2luLVBhdGggJHNjcmlwdERpciAncHJlc2V0JwokY29tcG9zZVBhdGggPSBKb2luLVBhdGggJHByZXNldERpciAnYWdlbnQuY29y
>>"%B64%" echo ZGlzLnltbCcKaWYgKFRlc3QtUGF0aCAoSm9pbi1QYXRoICRwcmVzZXRTcmMgJ2FnZW50LmNvcmRpcy55bWwnKSkgewogICAgQ29w
>>"%B64%" echo eS1JdGVtIChKb2luLVBhdGggJHByZXNldFNyYyAnKicpICRwcmVzZXREaXIgLVJlY3Vyc2UgLUZvcmNlCiAgICBTYXkgJyAgT0sg
>>"%B64%" echo 5Lq65qC86aKE6K6+5bey5a6J6KOFICjmlrDkvJror53lj6/pgIkgZWx5c2lhKScgJEdyZWVuCn0gZWxzZSB7CiAgICBTYXkgJyAg
>>"%B64%" echo 5pyq5om+5YiwIHByZXNldCDnm67lvZUsIOWMheWPr+iDveS4jeWujOaVtCcgJFllbGxvdwp9CgojIDJiLiDmjInmnKzmnLogZHNo
>>"%B64%" echo IOeJiOacrOagoeWHhumihOiuvumHjOeahOaPkuS7tuihjAojICAg6aKE6K6+6YeM55qEIHdvcmtmbG93IOihjOaYr+aMiSAwLjEu
>>"%B64%" echo NiDlhpnnmoQgKEBkZWVwc2Vlay1haS9kc2gtd29ya2Zsb3ctcHRjKSwg6ICMIDAuMS41LngKIyAgIOS4iuWPquaciSBAZGVlcHNl
>>"%B64%" echo ZWstYWkvZHNoLXdvcmtmbG93LXdvcmtlci10aHJlYWTjgILlkI3lrZflr7nkuI3kuIrml7YgRFNIIOS8muaKiuaVtOS4qumihOiu
>>"%B64%" echo vgojICAg5qCH5oiQ44CM5Yqg6L295aSx6LSl44CNKOe6ouiJsuagh+etviwg6YCJ6YO96YCJ5LiN5LqGKSwg5omA5Lul6L+Z6YeM
>>"%B64%" echo 5oyJ5a6e6ZmF6KOF5LqG55qE5YyF5o2i5ZCN44CCCiRoYXJuZXNzTm0gPSAkbnVsbAppZiAoJGRzaC5Tb3VyY2UpIHsKICAgICRu
>>"%B64%" echo cG1CaW4gPSBTcGxpdC1QYXRoICRkc2guU291cmNlIC1QYXJlbnQgICAgICAjIOS4gOiIrOaYryAlQVBQREFUQSVcbnBtCiAgICBm
>>"%B64%" echo b3JlYWNoICgkY2FuZCBpbiBAKAogICAgICAgIChKb2luLVBhdGggJG5wbUJpbiAnbm9kZV9tb2R1bGVzJyksCiAgICAgICAgKEpv
>>"%B64%" echo aW4tUGF0aCAoU3BsaXQtUGF0aCAkbnBtQmluIC1QYXJlbnQpICdub2RlX21vZHVsZXMnKQogICAgKSkgewogICAgICAgICRkc2hQ
>>"%B64%" echo a2cgPSBKb2luLVBhdGggJGNhbmQgJ0BkZWVwc2Vlay1haVxkc2hcbm9kZV9tb2R1bGVzJwogICAgICAgIGlmIChUZXN0LVBhdGgg
>>"%B64%" echo JGRzaFBrZykgeyAkaGFybmVzc05tID0gJGRzaFBrZzsgYnJlYWsgfQogICAgfQp9CmlmICgkaGFybmVzc05tIC1hbmQgKFRlc3Qt
>>"%B64%" echo UGF0aCAkY29tcG9zZVBhdGgpKSB7CiAgICAkeW1sID0gW0lPLkZpbGVdOjpSZWFkQWxsVGV4dCgkY29tcG9zZVBhdGgpCiAgICAk
>>"%B64%" echo aGFzUHRjID0gVGVzdC1QYXRoIChKb2luLVBhdGggJGhhcm5lc3NObSAnQGRlZXBzZWVrLWFpXGRzaC13b3JrZmxvdy1wdGMnKQog
>>"%B64%" echo ICAgJGhhc1dvcmtlciA9IFRlc3QtUGF0aCAoSm9pbi1QYXRoICRoYXJuZXNzTm0gJ0BkZWVwc2Vlay1haVxkc2gtd29ya2Zsb3ct
>>"%B64%" echo d29ya2VyLXRocmVhZCcpCiAgICBpZiAoLW5vdCAkaGFzUHRjIC1hbmQgJGhhc1dvcmtlciAtYW5kICR5bWwuQ29udGFpbnMoJ2Rz
>>"%B64%" echo aC13b3JrZmxvdy1wdGMnKSkgewogICAgICAgICR5bWwgPSAkeW1sLlJlcGxhY2UoJy0gaWQ6IHdvcmtmbG93LXB0YycsICctIGlk
>>"%B64%" echo OiB3b3JrZmxvdy13b3JrZXItdGhyZWFkJykuUmVwbGFjZSgnQGRlZXBzZWVrLWFpL2RzaC13b3JrZmxvdy1wdGMnLCAnQGRlZXBz
>>"%B64%" echo ZWVrLWFpL2RzaC13b3JrZmxvdy13b3JrZXItdGhyZWFkJykKICAgICAgICBbSU8uRmlsZV06OldyaXRlQWxsVGV4dCgkY29tcG9z
>>"%B64%" echo ZVBhdGgsICR5bWwsICRzY3JpcHQ6dXRmOE5vQm9tKQogICAgICAgIFNheSAnICBPSyDlt7LpgILphY3mnKzmnLogZHNoOiB3b3Jr
>>"%B64%" echo Zmxvdy1wdGMgLT4gd29ya2Zsb3ctd29ya2VyLXRocmVhZCcgJEdyZWVuCiAgICB9IGVsc2VpZiAoJGhhc1B0YykgewogICAgICAg
>>"%B64%" echo IFNheSAnICBPSyDmnKzmnLogZHNoIOiHquW4piBwdGMgd29ya2Zsb3csIOmihOiuvuaXoOmcgOaUueWKqCcgJEdyZWVuCiAgICB9
>>"%B64%" echo CgogICAgIyDoh6rmo4A6IOmihOiuvumHjOavj+S4gOihjOW8leeUqOeahOWMhSwg5pys5py65piv5LiN5piv55yf55qE6KOF5LqG
>>"%B64%" echo ICjoo4XkuI3kuIrkvJrmmL7npLrjgIzliqDovb3lpLHotKXjgI0pCiAgICAkbWlzc2luZyA9IEAoKQogICAgZm9yZWFjaCAoJG0g
>>"%B64%" echo aW4gW3JlZ2V4XTo6TWF0Y2hlcygkeW1sLCAibmFtZTpccyonKEBbXiddKyknIikpIHsKICAgICAgICAkc3BlYyA9ICRtLkdyb3Vw
>>"%B64%" echo c1sxXS5WYWx1ZQogICAgICAgICRwa2cgPSAoJHNwZWMuU3BsaXQoJy8nKVswLi4xXSAtam9pbiAnLycpCiAgICAgICAgaWYgKC1u
>>"%B64%" echo b3QgKFRlc3QtUGF0aCAoSm9pbi1QYXRoICRoYXJuZXNzTm0gKCRwa2cgLXJlcGxhY2UgJy8nLCAnXCcpKSkpIHsgJG1pc3Npbmcg
>>"%B64%" echo Kz0gJHNwZWMgfQogICAgfQogICAgJG1pc3NpbmcgPSBAKCRtaXNzaW5nIHwgU29ydC1PYmplY3QgLVVuaXF1ZSkKICAgIGlmICgk
>>"%B64%" echo bWlzc2luZy5Db3VudCAtZ3QgMCkgewogICAgICAgIFNheSAnICDms6jmhI86IOS7peS4i+aPkuS7tuihjOW8leeUqOeahOWMheac
>>"%B64%" echo rOacuuayoeaciSwg6aKE6K6+5Lya5pi+56S644CM5Yqg6L295aSx6LSl44CNOicgJFllbGxvdwogICAgICAgIGZvcmVhY2ggKCRu
>>"%B64%" echo IGluICRtaXNzaW5nKSB7IFNheSAiICAgIC0gJG4iICRZZWxsb3cgfQogICAgICAgIFNheSAnICDlpJrljYrmmK8gZHNoIOeJiOac
>>"%B64%" echo rOS4jumihOiuvuS4jeWMuemFjSDigJTigJQg5YyFMSDpkonnmoTmmK8gMC4xLjYtYWxwaGEuMicgJFllbGxvdwogICAgfSBlbHNl
>>"%B64%" echo IHsKICAgICAgICBTYXkgJyAgT0sg6aKE6K6+5byV55So55qE5o+S5Lu25pys5py66YO95pyJICjkuI3kvJrmnInjgIzliqDovb3l
>>"%B64%" echo pLHotKXjgI0pJyAkR3JlZW4KICAgIH0KfSBlbHNlIHsKICAgIFNheSAnICDot7Pov4fniYjmnKzoh6rmo4AgKOayoeaJvuWIsCBk
>>"%B64%" echo c2gg55qEIG5vZGVfbW9kdWxlcyknICRZZWxsb3cKfQoKIyAzLiDor63pn7MgKENvc3lWb2ljZSDlj6/pgIksIOS9k+enr+WkpykK
>>"%B64%" echo U2F5ICdbMy8zXSDor63pn7Ppg6jliIYgLi4uJwpTYXkgJyAg5rOo5oSPOiDlo7Dnur/ntKDmnZAgd2F2IOacqumaj+WMheWIhuWP
>>"%B64%" echo kSAo5ri45oiP6YWN6Z+z57Sg5p2QLCDniYjmnYPljp/lm6ApJyAkWWVsbG93ClNheSAnICAgICAgICDpnIDopoHnmoTor53ku47l
>>"%B64%" echo jp/mlbTlkIjljIXlpITojrflj5YsIOaUvuacrOWMhSB2b2ljZS1jbGlwcy8g5Y2z5Y+vJyAkWWVsbG93ClNheSAnICBDb3N5Vm9p
>>"%B64%" echo Y2Ug5qih5Z6LKOe6pjNHQikg6ZyA5omL5Yqo5LiL6L29OicgJFllbGxvdwpTYXkgJyAgICAxLiBodHRwczovL21vZGVsc2NvcGUu
>>"%B64%" echo Y24vbW9kZWxzL2lpYy9Db3N5Vm9pY2UyLTAuNUInClNheSAnICAgIDIuIOaooeWei+ino+WOi+WIsCBEOlxBSVxKQVJWSVNcbW9k
>>"%B64%" echo ZWxzXGNvc3l2b2ljZTJcJwpTYXkgJyAgICAzLiDlo7Dnur/mlofku7bmlL4gRDpcQUlcSkFSVklTXG1vZGVsc1xlbHlzaWEtdm9p
>>"%B64%" echo Y2VcY2xpcHNcZ3VpZGUtZWx5c2lhXCcKU2F5ICcgIOivpue7huatpemqpOingSBkb2NzXHZvaWNlLWd1aWRlLm1kICjot5/liIbo
>>"%B64%" echo uqsgcXEtZWx5c2lhLnB5IOaJvueahOi3r+W+hOS4gOiHtCknICRZZWxsb3cKCiMg6K6+572u6buY6K6k6aKE6K6+5Li6IGVseXNp
>>"%B64%" echo YQojICAg5rOo5oSPOiBzZXR0aW5ncy55YW1sIOmHjOW+gOW+gOW3sue7j+aciSBhZ2VudC1wcmVzZXRzIOautSAoV2ViIOiuvue9
>>"%B64%" echo rumhteWGmei/h+m7mOiupOWAvCksCiMgICDml6fniYjohJrmnKznnIvliLDov5nkuKrplK7lsLHnm7TmjqXot7Pov4csIOS6juaY
>>"%B64%" echo r+m7mOiupOWAvOS4gOebtOWBnOWcqCBzdGFuZGFyZCDigJTigJQg6L+Z6YeM5pS55oiQ5pS55YaZ5a6D44CCCiRzZXR0aW5nc1Bh
>>"%B64%" echo dGggPSBKb2luLVBhdGggJGRzaEhvbWUgJ3NldHRpbmdzLnlhbWwnCmlmICgtbm90IChUZXN0LVBhdGggJHNldHRpbmdzUGF0aCkp
>>"%B64%" echo IHsKICAgIFNheSAnICDmnKrmib7liLAgc2V0dGluZ3MueWFtbCwg6Lez6L+H6buY6K6k6aKE6K6+ICjor7flhYjoo4XljIUxIOW5
>>"%B64%" echo tuWQr+WKqOS4gOasoSBkc2gpJyAkWWVsbG93Cn0gZWxzZSB7CiAgICBDb3B5LUl0ZW0gJHNldHRpbmdzUGF0aCAiJHNldHRpbmdz
>>"%B64%" echo UGF0aC5iYWstcGtnMiIgLUZvcmNlCiAgICAkcmF3ID0gW0lPLkZpbGVdOjpSZWFkQWxsVGV4dCgkc2V0dGluZ3NQYXRoKQogICAg
>>"%B64%" echo JGVvbCA9IGlmICgkcmF3IC1tYXRjaCAiYHJgbiIpIHsgImByYG4iIH0gZWxzZSB7ICJgbiIgfQogICAgJGxpbmVzID0gTmV3LU9i
>>"%B64%" echo amVjdCBTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5MaXN0W3N0cmluZ10KICAgICRsaW5lcy5BZGRSYW5nZShbc3RyaW5nW11d
>>"%B64%" echo KCRyYXcgLXNwbGl0ICJgcj9gbiIpKQogICAgJGhkciA9IC0xCiAgICBmb3IgKCRpID0gMDsgJGkgLWx0ICRsaW5lcy5Db3VudDsg
>>"%B64%" echo JGkrKykgewogICAgICAgIGlmICgkbGluZXNbJGldIC1tYXRjaCAnXmFnZW50LXByZXNldHM6XHMqJCcpIHsgJGhkciA9ICRpOyBi
>>"%B64%" echo cmVhayB9CiAgICB9CiAgICBpZiAoJGhkciAtbHQgMCkgewogICAgICAgIGlmICgkcmF3Lkxlbmd0aCAtZ3QgMCAtYW5kIC1ub3Qg
>>"%B64%" echo JHJhdy5FbmRzV2l0aCgkZW9sKSkgeyAkbGluZXMuQWRkKCcnKSB9CiAgICAgICAgJGxpbmVzLkFkZCgnYWdlbnQtcHJlc2V0czon
>>"%B64%" echo KQogICAgICAgICRsaW5lcy5BZGQoJyAgZGVmYXVsdDogZWx5c2lhJykKICAgICAgICAkaG93ID0gJ+aWsOWiniBhZ2VudC1wcmVz
>>"%B64%" echo ZXRzIOautScKICAgIH0gZWxzZSB7CiAgICAgICAgJGRlZklkeCA9IC0xOyAkaW5kZW50ID0gJyAgJzsgJGNvbW1lbnQgPSAnJwog
>>"%B64%" echo ICAgICAgIGZvciAoJGkgPSAkaGRyICsgMTsgJGkgLWx0ICRsaW5lcy5Db3VudDsgJGkrKykgewogICAgICAgICAgICAkbCA9ICRs
>>"%B64%" echo aW5lc1skaV0KICAgICAgICAgICAgaWYgKCRsIC1tYXRjaCAnXlxTJykgeyBicmVhayB9ICAgICAgICAgICMg5LiL5LiA5q6155qE
>>"%B64%" echo 5byA5aS0LCDmnKzmrrXnu5PmnZ8KICAgICAgICAgICAgaWYgKCRsIC1tYXRjaCAnXlxzKiQnKSB7IGNvbnRpbnVlIH0KICAgICAg
>>"%B64%" echo ICAgICAgaWYgKCRsIC1tYXRjaCAnXihccyopZGVmYXVsdDonKSB7ICRkZWZJZHggPSAkaTsgJGluZGVudCA9ICRNYXRjaGVzWzFd
>>"%B64%" echo OyBicmVhayB9CiAgICAgICAgfQogICAgICAgIGlmICgkZGVmSWR4IC1nZSAwKSB7CiAgICAgICAgICAgIGlmICgkbGluZXNbJGRl
>>"%B64%" echo ZklkeF0gLW1hdGNoICcjKC4qKSQnKSB7ICRjb21tZW50ID0gJyAgIycgKyAkTWF0Y2hlc1sxXSB9CiAgICAgICAgICAgICRsaW5l
>>"%B64%" echo c1skZGVmSWR4XSA9ICIkaW5kZW50IiArICdkZWZhdWx0OiBlbHlzaWEnICsgJGNvbW1lbnQKICAgICAgICAgICAgJGhvdyA9ICfm
>>"%B64%" echo lLnlhpnlt7LmnInnmoQgZGVmYXVsdCcKICAgICAgICB9IGVsc2UgewogICAgICAgICAgICAkbGluZXMuSW5zZXJ0KCRoZHIgKyAx
>>"%B64%" echo LCAnICBkZWZhdWx0OiBlbHlzaWEnKQogICAgICAgICAgICAkaG93ID0gJ+ihpeS4iue8uuWkseeahCBkZWZhdWx0JwogICAgICAg
>>"%B64%" echo IH0KICAgIH0KICAgIFtJTy5GaWxlXTo6V3JpdGVBbGxUZXh0KCRzZXR0aW5nc1BhdGgsICgkbGluZXMgLWpvaW4gJGVvbCksICRz
>>"%B64%" echo Y3JpcHQ6dXRmOE5vQm9tKQogICAgU2F5ICIgIOW3suiuvue9rum7mOiupOmihOiuviA9IGVseXNpYSAoJGhvdzsg5pen5paH5Lu2
>>"%B64%" echo 5aSH5Lu95Li6IHNldHRpbmdzLnlhbWwuYmFrLXBrZzIpIiAkR3JlZW4KfQoKU2F5ICcnClNheSAnICDlrozmiJAhIOaWsOS8muiv
>>"%B64%" echo nem7mOiupOWwseaYr+eIseiOieW4jOmbhSAo5oOz5YaZ5Luj56CB5pe25YaN5omL5Yqo5YiHIHN0YW5kYXJkKScgJEdyZWVuClNh
>>"%B64%" echo eSAnICDlt7LlvIDnnYDnmoTnvZHpobXliLfmlrDkuIDkuIsgKEY1KSDlsLHog73nnIvliLDpooTorr47IOayoeWcqOi3keWwseWP
>>"%B64%" echo jOWHu+ahjOmdoiBzdGFydC1lbHlzaWEuYmF0JyAkR3JlZW4KU2F5ICcnClJlYWQtSG9zdCAn5oyJ5Zue6L2m5YWz6ZetJwo=
>>"%B64%" echo -----END CERTIFICATE-----

certutil -decode -f "%B64%" "%PS1%" >nul 2>&1

if not exist "%PS1%" (
    echo Decode failed. Please run as administrator.
    pause
    exit /b 1
)

pushd "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" "%CD%"
popd

del "%B64%" "%PS1%" >nul 2>&1

pause
