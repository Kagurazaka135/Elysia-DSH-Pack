@echo off

chcp 65001 >nul

net session >nul 2>&1

if %errorlevel% neq 0 (
    echo Requesting administrator permission...
    powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

title Elysia Installer

set "B64=%TEMP%\elysia-setup.b64"
set "PS1=%TEMP%\elysia-setup.ps1"

> "%B64%" echo -----BEGIN CERTIFICATE-----
>>"%B64%" echo 77u/IyAtKi0gY29kaW5nOiB1dGYtOCAtKi0KIyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09
>>"%B64%" echo PT09PT09PT09PT09PT0KIyAg5YyFMiDCtyDniLHojonkurrmoLwgKyDor63pn7Mg5LiA6ZSu5a6J6KOFCiMgIOWJjeaPkDog5bey
>>"%B64%" echo 6KOFIOWMhTEgKERlZXBTZWVrIEhhcm5lc3MpCiMgIOeUqOazlTog5Y+M5Ye7IGluc3RhbGwuYmF0IC0+IOiHquWKqOWujOaIkAoj
>>"%B64%" echo ICDljIXlkKs6IOeIseiOieS6uuagvOmihOiuviArIOesrOS4gOeJiOWjsOe6vyAoQ29zeVZvaWNlKQojID09PT09PT09PT09PT09
>>"%B64%" echo PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PQokRXJyb3JBY3Rpb25QcmVmZXJlbmNlID0gJ1N0
>>"%B64%" echo b3AnCiRDeWFuID0gJ0N5YW4nOyAkR3JlZW4gPSAnR3JlZW4nOyAkWWVsbG93ID0gJ1llbGxvdyc7ICRQaW5rID0gJ01hZ2VudGEn
>>"%B64%" echo CmZ1bmN0aW9uIFNheSgkbSwgJGMgPSAkQ3lhbikgeyBXcml0ZS1Ib3N0ICIgICRtIiAtRm9yZWdyb3VuZENvbG9yICRjIH0KCiMg
>>"%B64%" echo VVRGLTgg5pegIEJPTSDlhpnlhaU6IFBTNS4xIOeahCBBZGQtQ29udGVudCAtRW5jb2RpbmcgVVRGOCDkvJrmioogQk9NIOa3t+i/
>>"%B64%" echo m+W3suacieaWh+S7tiwKIyBZQU1MIOino+aekOWZqOWvueS4remXtOWGkuWHuuadpeeahCBCT00g5LiN5LiA5a6a5a655b+NIOKA
>>"%B64%" echo lOKAlCDnu5/kuIDor7vov5vmnaXov73liqDlho3nlKjml6AgQk9NIOWGmeWbngokc2NyaXB0OnV0ZjhOb0JvbSA9IE5ldy1PYmpl
>>"%B64%" echo Y3QgU3lzdGVtLlRleHQuVVRGOEVuY29kaW5nKCRmYWxzZSkKClNheSAn4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ
>>"%B64%" echo 4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ
>>"%B64%" echo 4pWQ4pWQJyAkUGluawpTYXkgJyAg54ix6I6J5biM6ZuFIMK3IOS6uuagvOS4juivremfs+WuieijhScgJFBpbmsKU2F5ICfilZDi
>>"%B64%" echo lZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDi
>>"%B64%" echo lZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZAnICRQaW5rClNheSAnJwoKJGRzaEhvbWUgPSBKb2luLVBhdGggJGVu
>>"%B64%" echo djpVU0VSUFJPRklMRSAnLmRzaCcKJHNjcmlwdERpciA9ICgkYXJnc1swXSAtcmVwbGFjZSAnIicsICcnKS5UcmltRW5kKCdcJykK
>>"%B64%" echo CiMgMS4g5qOA5p+lIERTSApTYXkgJ1sxLzNdIOajgOafpSBEZWVwU2VlayBIYXJuZXNzIC4uLicKJGRzaCA9IEdldC1Db21tYW5k
>>"%B64%" echo IGRzaCAtRXJyb3JBY3Rpb24gU2lsZW50bHlDb250aW51ZQppZiAoLW5vdCAkZHNoKSB7CiAgICBTYXkgJyAg5pyq5qOA5rWL5Yiw
>>"%B64%" echo IERTSCwg6K+35YWI5a6J6KOFIOWMhTEgKOaguOW/g+WMhSkhJyAkWWVsbG93CiAgICBSZWFkLUhvc3QgJ+aMieWbnui9pumAgOWH
>>"%B64%" echo uic7IGV4aXQgMQp9ClNheSAnICBPSycgJEdyZWVuCgojIDIuIOWuieijheS6uuagvOmihOiuvgpTYXkgJ1syLzNdIOWuieijheeI
>>"%B64%" echo seiOieS6uuagvCAuLi4nCiRwcmVzZXREaXIgPSBKb2luLVBhdGggJGRzaEhvbWUgJy5hZ2VudC1wcmVzZXRzXGVseXNpYScKTmV3
>>"%B64%" echo LUl0ZW0gLUl0ZW1UeXBlIERpcmVjdG9yeSAtUGF0aCAkcHJlc2V0RGlyIC1Gb3JjZSB8IE91dC1OdWxsCiRwcmVzZXRTcmMgPSBK
>>"%B64%" echo b2luLVBhdGggJHNjcmlwdERpciAncHJlc2V0JwokY29tcG9zZVBhdGggPSBKb2luLVBhdGggJHByZXNldERpciAnYWdlbnQuY29y
>>"%B64%" echo ZGlzLnltbCcKaWYgKFRlc3QtUGF0aCAoSm9pbi1QYXRoICRwcmVzZXRTcmMgJ2FnZW50LmNvcmRpcy55bWwnKSkgewogICAgQ29w
>>"%B64%" echo eS1JdGVtIChKb2luLVBhdGggJHByZXNldFNyYyAnKicpICRwcmVzZXREaXIgLVJlY3Vyc2UgLUZvcmNlCiAgICBTYXkgJyAgT0sg
>>"%B64%" echo 5Lq65qC86aKE6K6+5bey5a6J6KOFICjmlrDkvJror53lj6/pgIkgZWx5c2lhKScgJEdyZWVuCn0gZWxzZSB7CiAgICBTYXkgJyAg
>>"%B64%" echo 5pyq5om+5YiwIHByZXNldCDnm67lvZUsIOWMheWPr+iDveS4jeWujOaVtCcgJFllbGxvdwp9CgojIDJiLiDmjInmnKzmnLogZHNo
>>"%B64%" echo IOeJiOacrOagoeWHhumihOiuvumHjOeahOaPkuS7tuihjAojICAg6aKE6K6+6YeM55qEIHdvcmtmbG93IOihjOaYr+aMiSAwLjEu
>>"%B64%" echo NiDlhpnnmoQgKEBkZWVwc2Vlay1haS9kc2gtd29ya2Zsb3ctcHRjKSwg6ICMIDAuMS41LngKIyAgIOS4iuWPquaciSBAZGVlcHNl
>>"%B64%" echo ZWstYWkvZHNoLXdvcmtmbG93LXdvcmtlci10aHJlYWTjgILlkI3lrZflr7nkuI3kuIrml7YgRFNIIOS8muaKiuaVtOS4qumihOiu
>>"%B64%" echo vgojICAg5qCH5oiQ44CM5Yqg6L295aSx6LSl44CNKOe6ouiJsuagh+etviwg6YCJ6YO96YCJ5LiN5LqGKSwg5omA5Lul6L+Z6YeM
>>"%B64%" echo 5oyJ5a6e6ZmF6KOF5LqG55qE5YyF5o2i5ZCN44CCCiMKIyAgIEE5IOWunua1iyAoMC4xLjYtYWxwaGEuMiArIG5wbSB2MTEg5YWo
>>"%B64%" echo 5bGA5a6J6KOFKTog5L6d6LWW5LiN5o+Q5Y2H5Yiw6aG25bGCLCDlhajlnKjltYzlpZflsYIKIyAgIDxucG0gcm9vdCAtZz5cQGRl
>>"%B64%" echo ZXBzZWVrLWFpXGRzaFxub2RlX21vZHVsZXNcQGRlZXBzZWVrLWFpXCAoMjU5IOS4quWMhSksCiMgICDpobblsYLlj6rmnIkgZHNo
>>"%B64%" echo IOacrOS9k+OAguS9hiBucG0g54mI5pysL+WuieijheaWueW8jyAocG5wbeOAgW52bSBzaGltKSDkuI3lkIzluIPlsYDkvJrlj5gg
>>"%B64%" echo 4oCU4oCUCiMgICDmjqLmtYvmjInlgJnpgInliJfooajlhZzlupU6IOW1jOWll+WxgiAtPiDlhajlsYDpobblsYIgLT4g5oyJIGRz
>>"%B64%" echo aCDlkb3ku6TkvY3nva7mjqggLT4gcG5wbSDlhajlsYA7CiMgICDoh6rmo4Dml7bljIXlnKjku7vkvZXlgJnpgInlkb3kuK3pg73n
>>"%B64%" echo rpfjgIzmnInjgI0sIOS4jeWGjeWboOS4uuS4gOWxguayoeaOouWIsOWwseaVtOS9k+mdmem7mOi3s+i/h+OAggokcm9vdHMgPSBO
>>"%B64%" echo ZXctT2JqZWN0IFN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLkxpc3Rbc3RyaW5nXQpmdW5jdGlvbiBBZGQtUm9vdChbc3RyaW5n
>>"%B64%" echo XSRyKSB7CiAgICBpZiAoJHIpIHsgJHQgPSAkci5UcmltKCk7IGlmICgkdCAtYW5kIChUZXN0LVBhdGggJHQpKSB7ICRzY3JpcHQ6
>>"%B64%" echo cm9vdHMuQWRkKCR0KSB9IH0KfQokbnBtUm9vdEcgPSAoY21kIC9jICJucG0gcm9vdCAtZyAyPm51bCIgfCBTZWxlY3QtT2JqZWN0
>>"%B64%" echo IC1MYXN0IDEpCmlmICgkbnBtUm9vdEcpIHsKICAgIEFkZC1Sb290IChKb2luLVBhdGggJG5wbVJvb3RHLlRyaW0oKSAnQGRlZXBz
>>"%B64%" echo ZWVrLWFpXGRzaFxub2RlX21vZHVsZXMnKSAgICMg5bWM5aWX5biD5bGAICjlrp7mtYvkuLvot6/lvoQpCiAgICBBZGQtUm9vdCAk
>>"%B64%" echo bnBtUm9vdEcuVHJpbSgpICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAjIOmhtuWxguaPkOWN
>>"%B64%" echo h+W4g+WxgAp9CmlmICgkZHNoLlNvdXJjZSkgewogICAgJG5wbUJpbiA9IFNwbGl0LVBhdGggJGRzaC5Tb3VyY2UgLVBhcmVudCAg
>>"%B64%" echo ICAgICMg5YWc5bqVOiDmjIkgZHNoIOWRveS7pCBzaGltIOeahOS9jee9ruaOqCAobnZtIOetiSkKICAgIEFkZC1Sb290IChKb2lu
>>"%B64%" echo LVBhdGggJG5wbUJpbiAnbm9kZV9tb2R1bGVzXEBkZWVwc2Vlay1haVxkc2hcbm9kZV9tb2R1bGVzJykKICAgIEFkZC1Sb290IChK
>>"%B64%" echo b2luLVBhdGggJG5wbUJpbiAnbm9kZV9tb2R1bGVzJykKfQpBZGQtUm9vdCAoKGNtZCAvYyAicG5wbSByb290IC1nIDI+bnVsIiB8
>>"%B64%" echo IFNlbGVjdC1PYmplY3QgLUxhc3QgMSkpCkFkZC1Sb290ICgoY21kIC9jICJwbnBtIHJvb3QgLWcgMj5udWwiIHwgU2VsZWN0LU9i
>>"%B64%" echo amVjdCAtTGFzdCAxKSArICdcQGRlZXBzZWVrLWFpXGRzaFxub2RlX21vZHVsZXMnKQokcm9vdHMgPSBAKCRyb290cyB8IFNlbGVj
>>"%B64%" echo dC1PYmplY3QgLVVuaXF1ZSkKCmlmICgkcm9vdHMuQ291bnQgLWd0IDAgLWFuZCAoVGVzdC1QYXRoICRjb21wb3NlUGF0aCkpIHsK
>>"%B64%" echo ICAgICR5bWwgPSBbSU8uRmlsZV06OlJlYWRBbGxUZXh0KCRjb21wb3NlUGF0aCkKICAgICRoYXNQdGMgPSAkZmFsc2U7ICRoYXNX
>>"%B64%" echo b3JrZXIgPSAkZmFsc2UKICAgIGZvcmVhY2ggKCRyIGluICRyb290cykgewogICAgICAgIGlmIChUZXN0LVBhdGggKEpvaW4tUGF0
>>"%B64%" echo aCAkciAnQGRlZXBzZWVrLWFpXGRzaC13b3JrZmxvdy1wdGMnKSkgeyAkaGFzUHRjID0gJHRydWUgfQogICAgICAgIGlmIChUZXN0
>>"%B64%" echo LVBhdGggKEpvaW4tUGF0aCAkciAnQGRlZXBzZWVrLWFpXGRzaC13b3JrZmxvdy13b3JrZXItdGhyZWFkJykpIHsgJGhhc1dvcmtl
>>"%B64%" echo ciA9ICR0cnVlIH0KICAgIH0KICAgIGlmICgtbm90ICRoYXNQdGMgLWFuZCAkaGFzV29ya2VyIC1hbmQgJHltbC5Db250YWlucygn
>>"%B64%" echo ZHNoLXdvcmtmbG93LXB0YycpKSB7CiAgICAgICAgJHltbCA9ICR5bWwuUmVwbGFjZSgnLSBpZDogd29ya2Zsb3ctcHRjJywgJy0g
>>"%B64%" echo aWQ6IHdvcmtmbG93LXdvcmtlci10aHJlYWQnKS5SZXBsYWNlKCdAZGVlcHNlZWstYWkvZHNoLXdvcmtmbG93LXB0YycsICdAZGVl
>>"%B64%" echo cHNlZWstYWkvZHNoLXdvcmtmbG93LXdvcmtlci10aHJlYWQnKQogICAgICAgIFtJTy5GaWxlXTo6V3JpdGVBbGxUZXh0KCRjb21w
>>"%B64%" echo b3NlUGF0aCwgJHltbCwgJHNjcmlwdDp1dGY4Tm9Cb20pCiAgICAgICAgU2F5ICcgIE9LIOW3sumAgumFjeacrOacuiBkc2g6IHdv
>>"%B64%" echo cmtmbG93LXB0YyAtPiB3b3JrZmxvdy13b3JrZXItdGhyZWFkJyAkR3JlZW4KICAgIH0gZWxzZWlmICgkaGFzUHRjKSB7CiAgICAg
>>"%B64%" echo ICAgU2F5ICcgIE9LIOacrOacuiBkc2gg6Ieq5bimIHB0YyB3b3JrZmxvdywg6aKE6K6+5peg6ZyA5pS55YqoJyAkR3JlZW4KICAg
>>"%B64%" echo IH0KCiAgICAjIOiHquajgDog6aKE6K6+6YeM5q+P5LiA6KGM5byV55So55qE5YyFLCDmnKzmnLrmmK/kuI3mmK/nnJ/nmoToo4Xk
>>"%B64%" echo uoYgKOijheS4jeS4iuS8muaYvuekuuOAjOWKoOi9veWksei0peOAjSkKICAgICRtaXNzaW5nID0gQCgpCiAgICBmb3JlYWNoICgk
>>"%B64%" echo bSBpbiBbcmVnZXhdOjpNYXRjaGVzKCR5bWwsICJuYW1lOlxzKicoQFteJ10rKSciKSkgewogICAgICAgICRzcGVjID0gJG0uR3Jv
>>"%B64%" echo dXBzWzFdLlZhbHVlCiAgICAgICAgJHBrZyA9ICgkc3BlYy5TcGxpdCgnLycpWzAuLjFdIC1qb2luICcvJykKICAgICAgICAkZm91
>>"%B64%" echo bmQgPSAkZmFsc2UKICAgICAgICBmb3JlYWNoICgkciBpbiAkcm9vdHMpIHsKICAgICAgICAgICAgaWYgKFRlc3QtUGF0aCAoSm9p
>>"%B64%" echo bi1QYXRoICRyICgkcGtnIC1yZXBsYWNlICcvJywgJ1wnKSkpIHsgJGZvdW5kID0gJHRydWU7IGJyZWFrIH0KICAgICAgICB9CiAg
>>"%B64%" echo ICAgICAgaWYgKC1ub3QgJGZvdW5kKSB7ICRtaXNzaW5nICs9ICRzcGVjIH0KICAgIH0KICAgICRtaXNzaW5nID0gQCgkbWlzc2lu
>>"%B64%" echo ZyB8IFNvcnQtT2JqZWN0IC1VbmlxdWUpCiAgICBpZiAoJG1pc3NpbmcuQ291bnQgLWd0IDApIHsKICAgICAgICBTYXkgJyAg5rOo
>>"%B64%" echo 5oSPOiDku6XkuIvmj5Lku7booYzlvJXnlKjnmoTljIXmnKzmnLrmsqHmnIksIOmihOiuvuS8muaYvuekuuOAjOWKoOi9veWksei0
>>"%B64%" echo peOAjTonICRZZWxsb3cKICAgICAgICBmb3JlYWNoICgkbiBpbiAkbWlzc2luZykgeyBTYXkgIiAgICAtICRuIiAkWWVsbG93IH0K
>>"%B64%" echo ICAgICAgICBTYXkgJyAg5aSa5Y2K5pivIGRzaCDniYjmnKzkuI7pooTorr7kuI3ljLnphY0g4oCU4oCUIOWMhTEg6ZKJ55qE5piv
>>"%B64%" echo IDAuMS42LWFscGhhLjInICRZZWxsb3cKICAgIH0gZWxzZSB7CiAgICAgICAgU2F5ICcgIE9LIOmihOiuvuW8leeUqOeahOaPkuS7
>>"%B64%" echo tuacrOacuumDveaciSAo5LiN5Lya5pyJ44CM5Yqg6L295aSx6LSl44CNKScgJEdyZWVuCiAgICB9Cn0gZWxzZSB7CiAgICBTYXkg
>>"%B64%" echo JyAg6Lez6L+H54mI5pys6Ieq5qOAICjmsqHmib7liLAgZHNoIOeahCBub2RlX21vZHVsZXMpJyAkWWVsbG93Cn0KCiMgMy4g6K+t
>>"%B64%" echo 6Z+zIChDb3N5Vm9pY2Ug5Y+v6YCJLCDkvZPnp6/lpKcpClNheSAnWzMvM10g6K+t6Z+z6YOo5YiGIC4uLicKU2F5ICcgIOazqOaE
>>"%B64%" echo jzog5aOw57q/57Sg5p2QIHdhdiDmnKrpmo/ljIXliIblj5EgKOa4uOaIj+mFjemfs+e0oOadkCwg54mI5p2D5Y6f5ZugKScgJFll
>>"%B64%" echo bGxvdwpTYXkgJyAgICAgICAg6ZyA6KaB55qE6K+d5LuO5Y6f5pW05ZCI5YyF5aSE6I635Y+WLCDmlL7mnKzljIUgdm9pY2UtY2xp
>>"%B64%" echo cHMvIOWNs+WPrycgJFllbGxvdwpTYXkgJyAgQ29zeVZvaWNlIOaooeWeiyjnuqYzR0IpIOmcgOaJi+WKqOS4i+i9vTonICRZZWxs
>>"%B64%" echo b3cKU2F5ICcgICAgMS4gaHR0cHM6Ly9tb2RlbHNjb3BlLmNuL21vZGVscy9paWMvQ29zeVZvaWNlMi0wLjVCJwpTYXkgJyAgICAy
>>"%B64%" echo LiDmqKHlnovop6PljovliLAgRDpcQUlcSkFSVklTXG1vZGVsc1xjb3N5dm9pY2UyXCcKU2F5ICcgICAgMy4g5aOw57q/5paH5Lu2
>>"%B64%" echo 5pS+IEQ6XEFJXEpBUlZJU1xtb2RlbHNcZWx5c2lhLXZvaWNlXGNsaXBzXGd1aWRlLWVseXNpYVwnClNheSAnICDor6bnu4bmraXp
>>"%B64%" echo qqTop4EgZG9jc1x2b2ljZS1ndWlkZS5tZCAo6Lef5YiG6LqrIHFxLWVseXNpYS5weSDmib7nmoTot6/lvoTkuIDoh7QpJyAkWWVs
>>"%B64%" echo bG93CgojIOiuvue9rum7mOiupOmihOiuvuS4uiBlbHlzaWEKIyAgIOazqOaEjzogc2V0dGluZ3MueWFtbCDph4zlvoDlvoDlt7Ln
>>"%B64%" echo u4/mnIkgYWdlbnQtcHJlc2V0cyDmrrUgKFdlYiDorr7nva7pobXlhpnov4fpu5jorqTlgLwpLAojICAg5pen54mI6ISa5pys55yL
>>"%B64%" echo 5Yiw6L+Z5Liq6ZSu5bCx55u05o6l6Lez6L+HLCDkuo7mmK/pu5jorqTlgLzkuIDnm7TlgZzlnKggc3RhbmRhcmQg4oCU4oCUIOi/
>>"%B64%" echo memHjOaUueaIkOaUueWGmeWug+OAggokc2V0dGluZ3NQYXRoID0gSm9pbi1QYXRoICRkc2hIb21lICdzZXR0aW5ncy55YW1sJwpp
>>"%B64%" echo ZiAoLW5vdCAoVGVzdC1QYXRoICRzZXR0aW5nc1BhdGgpKSB7CiAgICBTYXkgJyAg5pyq5om+5YiwIHNldHRpbmdzLnlhbWwsIOi3
>>"%B64%" echo s+i/h+m7mOiupOmihOiuviAo6K+35YWI6KOF5YyFMSDlubblkK/liqjkuIDmrKEgZHNoKScgJFllbGxvdwp9IGVsc2UgewogICAg
>>"%B64%" echo Q29weS1JdGVtICRzZXR0aW5nc1BhdGggIiRzZXR0aW5nc1BhdGguYmFrLXBrZzIiIC1Gb3JjZQogICAgJHJhdyA9IFtJTy5GaWxl
>>"%B64%" echo XTo6UmVhZEFsbFRleHQoJHNldHRpbmdzUGF0aCkKICAgICRlb2wgPSBpZiAoJHJhdyAtbWF0Y2ggImByYG4iKSB7ICJgcmBuIiB9
>>"%B64%" echo IGVsc2UgeyAiYG4iIH0KICAgICRsaW5lcyA9IE5ldy1PYmplY3QgU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuTGlzdFtzdHJp
>>"%B64%" echo bmddCiAgICAkbGluZXMuQWRkUmFuZ2UoW3N0cmluZ1tdXSgkcmF3IC1zcGxpdCAiYHI/YG4iKSkKICAgICRoZHIgPSAtMQogICAg
>>"%B64%" echo Zm9yICgkaSA9IDA7ICRpIC1sdCAkbGluZXMuQ291bnQ7ICRpKyspIHsKICAgICAgICBpZiAoJGxpbmVzWyRpXSAtbWF0Y2ggJ15h
>>"%B64%" echo Z2VudC1wcmVzZXRzOlxzKiQnKSB7ICRoZHIgPSAkaTsgYnJlYWsgfQogICAgfQogICAgaWYgKCRoZHIgLWx0IDApIHsKICAgICAg
>>"%B64%" echo ICBpZiAoJHJhdy5MZW5ndGggLWd0IDAgLWFuZCAtbm90ICRyYXcuRW5kc1dpdGgoJGVvbCkpIHsgJGxpbmVzLkFkZCgnJykgfQog
>>"%B64%" echo ICAgICAgICRsaW5lcy5BZGQoJ2FnZW50LXByZXNldHM6JykKICAgICAgICAkbGluZXMuQWRkKCcgIGRlZmF1bHQ6IGVseXNpYScp
>>"%B64%" echo CiAgICAgICAgJGhvdyA9ICfmlrDlop4gYWdlbnQtcHJlc2V0cyDmrrUnCiAgICB9IGVsc2UgewogICAgICAgICRkZWZJZHggPSAt
>>"%B64%" echo MTsgJGluZGVudCA9ICcgICc7ICRjb21tZW50ID0gJycKICAgICAgICBmb3IgKCRpID0gJGhkciArIDE7ICRpIC1sdCAkbGluZXMu
>>"%B64%" echo Q291bnQ7ICRpKyspIHsKICAgICAgICAgICAgJGwgPSAkbGluZXNbJGldCiAgICAgICAgICAgIGlmICgkbCAtbWF0Y2ggJ15cUycp
>>"%B64%" echo IHsgYnJlYWsgfSAgICAgICAgICAjIOS4i+S4gOauteeahOW8gOWktCwg5pys5q6157uT5p2fCiAgICAgICAgICAgIGlmICgkbCAt
>>"%B64%" echo bWF0Y2ggJ15ccyokJykgeyBjb250aW51ZSB9CiAgICAgICAgICAgIGlmICgkbCAtbWF0Y2ggJ14oXHMqKWRlZmF1bHQ6JykgeyAk
>>"%B64%" echo ZGVmSWR4ID0gJGk7ICRpbmRlbnQgPSAkTWF0Y2hlc1sxXTsgYnJlYWsgfQogICAgICAgIH0KICAgICAgICBpZiAoJGRlZklkeCAt
>>"%B64%" echo Z2UgMCkgewogICAgICAgICAgICBpZiAoJGxpbmVzWyRkZWZJZHhdIC1tYXRjaCAnIyguKikkJykgeyAkY29tbWVudCA9ICcgICMn
>>"%B64%" echo ICsgJE1hdGNoZXNbMV0gfQogICAgICAgICAgICAkbGluZXNbJGRlZklkeF0gPSAiJGluZGVudCIgKyAnZGVmYXVsdDogZWx5c2lh
>>"%B64%" echo JyArICRjb21tZW50CiAgICAgICAgICAgICRob3cgPSAn5pS55YaZ5bey5pyJ55qEIGRlZmF1bHQnCiAgICAgICAgfSBlbHNlIHsK
>>"%B64%" echo ICAgICAgICAgICAgJGxpbmVzLkluc2VydCgkaGRyICsgMSwgJyAgZGVmYXVsdDogZWx5c2lhJykKICAgICAgICAgICAgJGhvdyA9
>>"%B64%" echo ICfooaXkuIrnvLrlpLHnmoQgZGVmYXVsdCcKICAgICAgICB9CiAgICB9CiAgICBbSU8uRmlsZV06OldyaXRlQWxsVGV4dCgkc2V0
>>"%B64%" echo dGluZ3NQYXRoLCAoJGxpbmVzIC1qb2luICRlb2wpLCAkc2NyaXB0OnV0ZjhOb0JvbSkKICAgIFNheSAiICDlt7Lorr7nva7pu5jo
>>"%B64%" echo rqTpooTorr4gPSBlbHlzaWEgKCRob3c7IOaXp+aWh+S7tuWkh+S7veS4uiBzZXR0aW5ncy55YW1sLmJhay1wa2cyKSIgJEdyZWVu
>>"%B64%" echo Cn0KClNheSAnJwpTYXkgJyAg5a6M5oiQISDmlrDkvJror53pu5jorqTlsLHmmK/niLHojonluIzpm4UgKOaDs+WGmeS7o+eggeaX
>>"%B64%" echo tuWGjeaJi+WKqOWIhyBzdGFuZGFyZCknICRHcmVlbgpTYXkgJyAg5bey5byA552A55qE572R6aG15Yi35paw5LiA5LiLIChGNSkg
>>"%B64%" echo 5bCx6IO955yL5Yiw6aKE6K6+OyDmsqHlnKjot5HlsLHlj4zlh7vmoYzpnaIgc3RhcnQtZWx5c2lhLmJhdCcgJEdyZWVuClNheSAn
>>"%B64%" echo JwpSZWFkLUhvc3QgJ+aMieWbnui9puWFs+mXrScK
>>"%B64%" echo -----END CERTIFICATE-----

certutil -decode -f "%B64%" "%PS1%" >nul 2>&1

if not exist "%PS1%" (
    echo Decode failed. Please run as administrator.
    pause
    exit /b 1
)

pushd "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" "%CD%"
popd

del "%B64%" "%PS1%" >nul 2>&1

pause
