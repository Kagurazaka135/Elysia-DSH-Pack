@echo off

chcp 65001 >nul

net session >nul 2>&1

if %errorlevel% neq 0 (
    echo Requesting administrator permission...
    powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

title Elysia Installer

set "B64=%TEMP%\elysia-setup.b64"
set "PS1=%TEMP%\elysia-setup.ps1"

> "%B64%" echo -----BEGIN CERTIFICATE-----
>>"%B64%" echo 77u/IyAtKi0gY29kaW5nOiB1dGYtOCAtKi0KIyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09
>>"%B64%" echo PT09PT09PT09PT09PT0KIyAg5YyFNCDCtyDop4bpopHnkIbop6Mg5LiA6ZSu5a6J6KOFCiMgIOWJjeaPkDog5bey6KOFIOWMhTEg
>>"%B64%" echo KOaguOW/g+WMhSkg5LiUIGRzaCB3ZWIg6IO95q2j5bi46LW3CiMgIOeUqOazlTog5Y+M5Ye7IGluc3RhbGwuYmF0CiMgIOWKn+iD
>>"%B64%" echo vTog54ix6I6J55yL6KeG6aKRICjlhoXlrrnmgLvnu5Mv5oq95binL+WcuuaZr+ajgOa1iy9HSUYv5YWD5pWw5o2uKQojICDkvp3o
>>"%B64%" echo tZY6IGZmbXBlZyArIGZmcHJvYmUg5b+F6aG75Zyo57O757ufIFBBVEggKOiEmuacrOajgOafpeW5tue7meaMh+W8lSwg5LiN6Ieq
>>"%B64%" echo 5Yqo6KOFKQojID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PQokRXJy
>>"%B64%" echo b3JBY3Rpb25QcmVmZXJlbmNlID0gJ1N0b3AnCiRDeWFuID0gJ0N5YW4nOyAkR3JlZW4gPSAnR3JlZW4nOyAkWWVsbG93ID0gJ1ll
>>"%B64%" echo bGxvdyc7ICRQaW5rID0gJ01hZ2VudGEnCmZ1bmN0aW9uIFNheSgkbSwgJGMgPSAkQ3lhbikgeyBXcml0ZS1Ib3N0ICIgICRtIiAt
>>"%B64%" echo Rm9yZWdyb3VuZENvbG9yICRjIH0KClNheSAn4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ
>>"%B64%" echo 4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQJyAkUGluawpT
>>"%B64%" echo YXkgJyAg54ix6I6J6KeG6aKR55CG6KejIMK3IOS4gOmUruWuieijhScgJFBpbmsKU2F5ICfilZDilZDilZDilZDilZDilZDilZDi
>>"%B64%" echo lZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDi
>>"%B64%" echo lZDilZDilZDilZDilZDilZAnICRQaW5rClNheSAnJwoKJGJhc2UgPSAnRDpcQUlcSkFSVklTJwokc2NyaXB0RGlyID0gKCRhcmdz
>>"%B64%" echo WzBdIC1yZXBsYWNlICciJywgJycpLlRyaW1FbmQoJ1wnKQpOZXctSXRlbSAtSXRlbVR5cGUgRGlyZWN0b3J5IC1QYXRoICRiYXNl
>>"%B64%" echo IC1Gb3JjZSB8IE91dC1OdWxsCgojIC0tLS0tLS0tLS0gWzEvNF0g546v5aKD5qOA5p+lIC0tLS0tLS0tLS0KU2F5ICdbMS80XSDm
>>"%B64%" echo o4Dmn6Xnjq/looMgLi4uJwppZiAoLW5vdCAoR2V0LUNvbW1hbmQgZHNoIC1FcnJvckFjdGlvbiBTaWxlbnRseUNvbnRpbnVlKSkg
>>"%B64%" echo ewogICAgU2F5ICcgIOacquajgOa1i+WIsCBEU0gsIOivt+WFiOWuieijhSDljIUxICjmoLjlv4PljIUpIScgJFllbGxvdwogICAg
>>"%B64%" echo UmVhZC1Ib3N0ICfmjInlm57ovabpgIDlh7onOyBleGl0IDEKfQojIGRzaCDnmoTmj5Lku7bnrqHnkIblhoXpg6jovazlj5Hnu5kg
>>"%B64%" echo cG5wbSwg5rKh5pyJIHBucG0g5Lya55u05o6l5aSx6LSlIChleGl0IDEyNykKaWYgKC1ub3QgKEdldC1Db21tYW5kIHBucG0gLUVy
>>"%B64%" echo cm9yQWN0aW9uIFNpbGVudGx5Q29udGludWUpKSB7CiAgICBTYXkgJyAg5pyq5qOA5rWL5YiwIHBucG0sIOato+WcqOWuieijhSAu
>>"%B64%" echo Li4nICRZZWxsb3cKICAgIGNtZCAvYyAibnBtIGluc3RhbGwgLWcgcG5wbSA+bnVsIDI+JjEiCiAgICBpZiAoLW5vdCAoR2V0LUNv
>>"%B64%" echo bW1hbmQgcG5wbSAtRXJyb3JBY3Rpb24gU2lsZW50bHlDb250aW51ZSkpIHsKICAgICAgICBTYXkgJyAgISEgcG5wbSDoo4XkuI3k
>>"%B64%" echo uIosIOivt+aJi+WKqOaJp+ihjDogbnBtIGluc3RhbGwgLWcgcG5wbScgJFllbGxvdwogICAgICAgIFJlYWQtSG9zdCAn5oyJ5Zue
>>"%B64%" echo 6L2m6YCA5Ye6JzsgZXhpdCAxCiAgICB9Cn0KU2F5ICcgIE9LIGRzaCArIHBucG0g6YO95ZyoJyAkR3JlZW4KCiMgZmZtcGVnIC8g
>>"%B64%" echo ZmZwcm9iZSDmmK/op4bpopHlip/og73nmoTlkb3moLnlrZA6IOayoeacieWug+aPkuS7tueFp+agt+WKoOi9vSwg5L2G5bel5YW3
>>"%B64%" echo 5LiA6LCD5bCx5oql6ZSZ44CCCiMg5Y+q5o+Q56S65LiN6Ieq5Yqo6KOFIOKAlOKAlCBmZm1wZWcg5L2T56ev5aSn44CB6KOF5rOV
>>"%B64%" echo 5aSa44CB6Ieq5Yqo6KOF5a655piT57+76L2mLCDorqnnlKjmiLfmiYvliqjjgIIKJGZmID0gR2V0LUNvbW1hbmQgZmZtcGVnIC1F
>>"%B64%" echo cnJvckFjdGlvbiBTaWxlbnRseUNvbnRpbnVlCiRmcCA9IEdldC1Db21tYW5kIGZmcHJvYmUgLUVycm9yQWN0aW9uIFNpbGVudGx5
>>"%B64%" echo Q29udGludWUKaWYgKC1ub3QgJGZmIC1vciAtbm90ICRmcCkgewogICAgU2F5ICcnICRZZWxsb3cKICAgIFNheSAnICDmnKrmo4Dm
>>"%B64%" echo tYvliLAgZmZtcGVnIC8gZmZwcm9iZSDigJTigJQg6KeG6aKR5Yqf6IO95b+F6aG75L6d6LWW5a6DIScgJFllbGxvdwogICAgU2F5
>>"%B64%" echo ICcgIOayoeacieeahOivnTog5o+S5Lu26IO96KOF5LiKLCDkvYbmir3luKcvR0lGL+aAu+e7k+exu+W3peWFt+S4gOeUqOWwseaK
>>"%B64%" echo pemUmeOAgicgJFllbGxvdwogICAgU2F5ICcgIOivt+aJi+WKqOWuieijhSAo5LqM6YCJ5LiAKTonICRZZWxsb3cKICAgIFNheSAn
>>"%B64%" echo ICAgIDEuIOaWsOW8gOS4gOS4quWRveS7pOihjOeql+WPo+aJp+ihjDogIHdpbmdldCBpbnN0YWxsIEd5YW4uRkZtcGVnJyAkWWVs
>>"%B64%" echo bG93CiAgICBTYXkgJyAgICAgICDoo4XlrozopoHph43lvIDnqpflj6MgKOiuqSBQQVRIIOeUn+aViCknICRZZWxsb3cKICAgIFNh
>>"%B64%" echo eSAnICAgIDIuIOaIluWIsCBodHRwczovL3d3dy5neWFuLmRldi9mZm1wZWcvYnVpbGRzLyDkuIvovb0nICRZZWxsb3cKICAgIFNh
>>"%B64%" echo eSAnICAgICAgIHJlbGVhc2UtZXNzZW50aWFscy56aXAsIOino+WOi+WQjuaKiumHjOmdoueahCBiaW4g55uu5b2V5Yqg6L+b57O7
>>"%B64%" echo 57ufIFBBVEgnICRZZWxsb3cKICAgIFNheSAnICDlt7Loo4Xlpb3lsLHmjInlm57ovabnu6fnu607IOaDs+S7peWQjuWGjeijheWw
>>"%B64%" echo seebtOaOpeWFs+aOieacrOeql+WPo+OAgicgJFllbGxvdwogICAgUmVhZC1Ib3N0ICfmjInlm57ovabnu6fnu60nCiAgICAkZmYg
>>"%B64%" echo PSBHZXQtQ29tbWFuZCBmZm1wZWcgLUVycm9yQWN0aW9uIFNpbGVudGx5Q29udGludWUKICAgICRmcCA9IEdldC1Db21tYW5kIGZm
>>"%B64%" echo cHJvYmUgLUVycm9yQWN0aW9uIFNpbGVudGx5Q29udGludWUKfQppZiAoJGZmIC1hbmQgJGZwKSB7CiAgICAjIOS4iuWPpCBmZm1w
>>"%B64%" echo ZWcgKOavlOWmgiAyMDEzIOW5tOeahCkg6IO96LeRLCDkvYbmiYvmnLrmi43nmoQgSEVWQy9ILjI2NSDop4bpopHop6PkuI3liqgs
>>"%B64%" echo IOaPkOWJjeaPkOmGkgogICAgJHZlciA9ICgmIGZmbXBlZyAtdmVyc2lvbiB8IFNlbGVjdC1PYmplY3QgLUZpcnN0IDIpIC1qb2lu
>>"%B64%" echo ICcgJwogICAgJG1ham9yID0gJG51bGw7ICRidWlsdFllYXIgPSAkbnVsbAogICAgaWYgKCR2ZXIgLW1hdGNoICd2ZXJzaW9uXHMr
>>"%B64%" echo KFxkKylcLicpIHsgJG1ham9yID0gW2ludF0kTWF0Y2hlc1sxXSB9CiAgICBpZiAoJHZlciAtbWF0Y2ggJ2J1aWx0IG9uIC4qPyhc
>>"%B64%" echo ZHs0fSknKSB7ICRidWlsdFllYXIgPSBbaW50XSRNYXRjaGVzWzFdIH0KICAgIGlmICgoJG51bGwgLW5lICRtYWpvciAtYW5kICRt
>>"%B64%" echo YWpvciAtbHQgNCkgLW9yICgkbnVsbCAtZXEgJG1ham9yIC1hbmQgJG51bGwgLW5lICRidWlsdFllYXIgLWFuZCAkYnVpbHRZZWFy
>>"%B64%" echo IC1sdCAyMDE5KSkgewogICAgICAgIFNheSAiICAhISDmo4DmtYvliLDlvojogIHnmoQgZmZtcGVnOiAkKCR2ZXIuU3Vic3RyaW5n
>>"%B64%" echo KDAsIFtNYXRoXTo6TWluKDcwLCAkdmVyLkxlbmd0aCkpKSIgJFllbGxvdwogICAgICAgIFNheSAnICAgICDluLjop4Top4bpopHo
>>"%B64%" echo g73nlKgsIOS9huaJi+acuuaLjeeahCBIRVZDL0guMjY1IOS8muino+S4jeWKqCAo5oq95bin5aSx6LSlKeOAgicgJFllbGxvdwog
>>"%B64%" echo ICAgICAgIFNheSAnICAgICDlu7rorq7mjaLmlrDniYg6IHdpbmdldCBpbnN0YWxsIEd5YW4uRkZtcGVnICjms6jmhI/orqnmlrDn
>>"%B64%" echo iYjnm5bov4fml6fniYggUEFUSCknICRZZWxsb3cKICAgIH0gZWxzZSB7CiAgICAgICAgU2F5ICcgIE9LIGZmbXBlZyDlt7LlsLHk
>>"%B64%" echo vY0nICRHcmVlbgogICAgfQp9IGVsc2UgewogICAgU2F5ICcgICEhIGZmbXBlZyDku43mnKrmo4DmtYvliLAg4oCU4oCUIOWFiOe7
>>"%B64%" echo p+e7reijheaPkuS7tiwg6KeG6aKR5Yqf6IO95pqC5LiN5Y+v55So44CCJyAkWWVsbG93CiAgICBTYXkgJyAgICAg5Lul5ZCO6KOF
>>"%B64%" echo 5aW9IGZmbXBlZyDph43lkK8gZHNoIHdlYiDljbPlj68sIOS4jeeUqOmHjei3keacrOWMheOAgicgJFllbGxvdwp9CgojIC0tLS0t
>>"%B64%" echo LS0tLS0gWzIvNF0g5aSN5Yi25o+S5Lu2IC0tLS0tLS0tLS0KU2F5ICdbMi80XSDlpI3liLbmj5Lku7YgLi4uJwokcGx1Z2luRGly
>>"%B64%" echo ID0gSm9pbi1QYXRoICRiYXNlICdkc2gtdmlkZW8tZnJhbWVzJwpOZXctSXRlbSAtSXRlbVR5cGUgRGlyZWN0b3J5IC1QYXRoICRw
>>"%B64%" echo bHVnaW5EaXIgLUZvcmNlIHwgT3V0LU51bGwKQ29weS1JdGVtIChKb2luLVBhdGggJHNjcmlwdERpciAncGx1Z2luXConKSAkcGx1
>>"%B64%" echo Z2luRGlyIC1SZWN1cnNlIC1Gb3JjZQpTYXkgJyAgT0sg5bey5aSN5Yi25YiwIEQ6XEFJXEpBUlZJU1xkc2gtdmlkZW8tZnJhbWVz
>>"%B64%" echo JyAkR3JlZW4KCiMgLS0tLS0tLS0tLSBbMy80XSDlronoo4Xmj5Lku7bkvp3otZYgLS0tLS0tLS0tLQojIOaPkuS7tuW/hemhu+iH
>>"%B64%" echo quW4puS4gOS7vSBub2RlX21vZHVsZXM6IGRzaCDnmoQgcHJvZmlsZSDlj6roo4UgYnVuZGxlIOiHqui6qywKIyDkuI3mj5Dkvpvm
>>"%B64%" echo j5Lku7bopoHnlKjnmoQgQGRlZXBzZWVrLWFpLyog5YyFLCDpnaAgcHJvZmlsZSDmmK/op6PmnpDkuI3liLDnmoTjgIIKU2F5ICdb
>>"%B64%" echo My80XSDlronoo4Xmj5Lku7bkvp3otZYgKOiBlOe9kSwg57qmIDEg5YiG6ZKfKSAuLi4nClB1c2gtTG9jYXRpb24gJHBsdWdpbkRp
>>"%B64%" echo cgpjbWQgL2MgIm5wbSBpbnN0YWxsIC0tbm8tYXVkaXQgLS1uby1mdW5kID5udWwgMj4mMSIKJG5wbU9rID0gKCRMQVNURVhJVENP
>>"%B64%" echo REUgLWVxIDApIC1hbmQgKFRlc3QtUGF0aCAoSm9pbi1QYXRoICRwbHVnaW5EaXIgJ25vZGVfbW9kdWxlcycpKQpQb3AtTG9jYXRp
>>"%B64%" echo b24KaWYgKCRucG1PaykgewogICAgU2F5ICcgIE9LIOS+nei1luW3suWwseS9jScgJEdyZWVuCn0gZWxzZSB7CiAgICBTYXkgJyAg
>>"%B64%" echo ISEg5L6d6LWW5rKh6KOF5LiKLCDmj5Lku7bkvJrliqDovb3lpLHotKUnICRZZWxsb3cKICAgIFNheSAnICAgICDmiYvliqjph43o
>>"%B64%" echo r5U6IGNkIEQ6XEFJXEpBUlZJU1xkc2gtdmlkZW8tZnJhbWVzICYmIG5wbSBpbnN0YWxsJyAkWWVsbG93Cn0KCiMgLS0tLS0tLS0t
>>"%B64%" echo LSBbNC80XSDoo4Xov5sgRFNIIC0tLS0tLS0tLS0KIyDmnKzmj5Lku7bkuI3pnIDopoHlvoAgcHJvZmlsZSDnmoQgY29yZGlzLnBh
>>"%B64%" echo dGNoLnltbCDlhpnphY3nva4gKOS4jeWDjyBRUSDmoaXopoEgdG9rZW4vY3dkKSwKIyBidW5kbGUgcGF0Y2gg55Sx5o+S5Lu26Ieq
>>"%B64%" echo 5bim55qEIGNvcmRpcy5wYXRjaC55bWwg5o+Q5L6b44CCClNheSAnWzQvNF0g5oqK5o+S5Lu26KOF6L+bIERTSCAocHJvZmlsZTog
>>"%B64%" echo d2ViKSAuLi4nCiRwbHVnaW5EaXJTbGFzaCA9ICRwbHVnaW5EaXIuUmVwbGFjZSgnXCcsICcvJykKY21kIC9jICJkc2ggcGx1Z2lu
>>"%B64%" echo IC0tcHJvZmlsZSB3ZWIgYWRkIGAiJHBsdWdpbkRpclNsYXNoYCIgMj4mMSIKaWYgKCRMQVNURVhJVENPREUgLW5lIDApIHsKICAg
>>"%B64%" echo IFNheSAnICAhISDoo4Xov5sgRFNIIOWksei0pSAo5LiK6Z2i5pyJ5oql6ZSZLCDlj6/lpI3liLbnu5nkvZzogIUpJyAkWWVsbG93
>>"%B64%" echo Cn0gZWxzZSB7CiAgICBTYXkgJyAgT0sg5o+S5Lu25bey6L+bIHdlYiBwcm9maWxlJyAkR3JlZW4KfQoKU2F5ICcnClNheSAnICDo
>>"%B64%" echo o4XlrozkuoY6JyAkR3JlZW4KU2F5ICcgIDEuIOmHjeWQryBkc2ggd2ViOiDlhbPmjonlroPnmoTnqpflj6MsIOWGjeWPjOWHu+ah
>>"%B64%" echo jOmdoueahCBzdGFydC1lbHlzaWEuYmF0JyAkR3JlZW4KU2F5ICcgIDIuIOa1j+iniOWZqOaJk+W8gCBodHRwOi8vMTI3LjAuMC4x
>>"%B64%" echo OjMwODAsIOebtOaOpeWvueeIseiOieivtDonICRHcmVlbgpTYXkgJyAgICAgIuW4ruaIkeeci+S4iyBEOlx2aWRlb3NceHh4Lm1w
>>"%B64%" echo NCDph4zlj5HnlJ/kuobku4DkuYgiJyAkR3JlZW4KU2F5ICcgICAgICLmiorov5nmrrXop4bpopHlgZrmiJAgR0lGIiAvICLov5nk
>>"%B64%" echo uKrop4bpopHlpJrplb/jgIHku4DkuYjliIbovqjnjociJyAkR3JlZW4KU2F5ICcgIOivpue7huingeWMhemHjOeahCBSRUFETUUu
>>"%B64%" echo bWQnICRHcmVlbgpTYXkgJycKUmVhZC1Ib3N0ICfmjInlm57ovablhbPpl60nCg==
>>"%B64%" echo -----END CERTIFICATE-----

certutil -decode -f "%B64%" "%PS1%" >nul 2>&1

if not exist "%PS1%" (
    echo Decode failed. Please run as administrator.
    pause
    exit /b 1
)

pushd "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" "%CD%"
popd

del "%B64%" "%PS1%" >nul 2>&1

pause
