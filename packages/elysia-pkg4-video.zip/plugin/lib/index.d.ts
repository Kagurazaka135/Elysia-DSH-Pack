import type { Context } from '@deepseek-ai/cordis';
export declare const name = "dsh-video-frames";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
