@echo off

chcp 65001 >nul

net session >nul 2>&1

if %errorlevel% neq 0 (
    echo Requesting administrator permission...
    powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

title Elysia Installer

set "B64=%TEMP%\elysia-setup.b64"
set "PS1=%TEMP%\elysia-setup.ps1"

> "%B64%" echo -----BEGIN CERTIFICATE-----
>>"%B64%" echo 77u/IyAtKi0gY29kaW5nOiB1dGYtOCAtKi0NCiMgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09
>>"%B64%" echo PT09PT09PT09PT09PT09DQojICDljIUyIMK3IOeIseiOieS6uuagvCArIOivremfsyDkuIDplK7lronoo4UNCiMgIOWJjeaPkDog
>>"%B64%" echo 5bey6KOFIOWMhTEgKERlZXBTZWVrIEhhcm5lc3MpDQojICDnlKjms5U6IOWPjOWHuyBpbnN0YWxsLmJhdCAtPiDoh6rliqjlrozm
>>"%B64%" echo iJANCiMgIOWMheWQqzog54ix6I6J5Lq65qC86aKE6K6+ICsg56ys5LiA54mI5aOw57q/IChDb3N5Vm9pY2UpDQojID09PT09PT09
>>"%B64%" echo PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PQ0KJEVycm9yQWN0aW9uUHJlZmVyZW5j
>>"%B64%" echo ZSA9ICdTdG9wJw0KJEN5YW4gPSAnQ3lhbic7ICRHcmVlbiA9ICdHcmVlbic7ICRZZWxsb3cgPSAnWWVsbG93JzsgJFBpbmsgPSAn
>>"%B64%" echo TWFnZW50YScNCmZ1bmN0aW9uIFNheSgkbSwgJGMgPSAkQ3lhbikgeyBXcml0ZS1Ib3N0ICIgICRtIiAtRm9yZWdyb3VuZENvbG9y
>>"%B64%" echo ICRjIH0NCg0KU2F5ICfilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDi
>>"%B64%" echo lZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZAnICRQaW5rDQpTYXkgJyAg54ix6I6J
>>"%B64%" echo 5biM6ZuFIMK3IOS6uuagvOS4juivremfs+WuieijhScgJFBpbmsNClNheSAn4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ
>>"%B64%" echo 4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ
>>"%B64%" echo 4pWQ4pWQ4pWQJyAkUGluaw0KU2F5ICcnDQoNCiRkc2hIb21lID0gSm9pbi1QYXRoICRlbnY6VVNFUlBST0ZJTEUgJy5kc2gnDQok
>>"%B64%" echo c2NyaXB0RGlyID0gJGFyZ3NbMF0uVHJpbUVuZCgnXCcpDQoNCiMgMS4g5qOA5p+lIERTSA0KU2F5ICdbMS8zXSDmo4Dmn6UgRGVl
>>"%B64%" echo cFNlZWsgSGFybmVzcyAuLi4nDQokZHNoID0gR2V0LUNvbW1hbmQgZHNoIC1FcnJvckFjdGlvbiBTaWxlbnRseUNvbnRpbnVlDQpp
>>"%B64%" echo ZiAoLW5vdCAkZHNoKSB7DQogICAgU2F5ICcgIOacquajgOa1i+WIsCBEU0gsIOivt+WFiOWuieijhSDljIUxICjmoLjlv4PljIUp
>>"%B64%" echo IScgJFllbGxvdw0KICAgIFJlYWQtSG9zdCAn5oyJ5Zue6L2m6YCA5Ye6JzsgZXhpdCAxDQp9DQpTYXkgJyAgT0snICRHcmVlbg0K
>>"%B64%" echo DQojIDIuIOWuieijheS6uuagvOmihOiuvg0KU2F5ICdbMi8zXSDlronoo4XniLHojonkurrmoLwgLi4uJw0KJHByZXNldERpciA9
>>"%B64%" echo IEpvaW4tUGF0aCAkZHNoSG9tZSAnLmFnZW50LXByZXNldHNcZWx5c2lhJw0KTmV3LUl0ZW0gLUl0ZW1UeXBlIERpcmVjdG9yeSAt
>>"%B64%" echo UGF0aCAkcHJlc2V0RGlyIC1Gb3JjZSB8IE91dC1OdWxsDQokcHJlc2V0U3JjID0gSm9pbi1QYXRoICRzY3JpcHREaXIgJ3ByZXNl
>>"%B64%" echo dCcNCmlmIChUZXN0LVBhdGggKEpvaW4tUGF0aCAkcHJlc2V0U3JjICdhZ2VudC5jb3JkaXMueW1sJykpIHsNCiAgICBDb3B5LUl0
>>"%B64%" echo ZW0gKEpvaW4tUGF0aCAkcHJlc2V0U3JjICcqJykgJHByZXNldERpciAtUmVjdXJzZSAtRm9yY2UNCiAgICBTYXkgJyAgT0sg5Lq6
>>"%B64%" echo 5qC86aKE6K6+5bey5a6J6KOFICjmlrDkvJror53lj6/pgIkgZWx5c2lhKScgJEdyZWVuDQp9IGVsc2Ugew0KICAgIFNheSAnICDm
>>"%B64%" echo nKrmib7liLAgcHJlc2V0IOebruW9lSwg5YyF5Y+v6IO95LiN5a6M5pW0JyAkWWVsbG93DQp9DQoNCiMgMy4g6K+t6Z+zIChDb3N5
>>"%B64%" echo Vm9pY2Ug5Y+v6YCJLCDkvZPnp6/lpKcpDQpTYXkgJ1szLzNdIOivremfs+mDqOWIhiAuLi4nDQpTYXkgJyAg5rOo5oSPOiDlo7Dn
>>"%B64%" echo ur/ntKDmnZAgd2F2IOacqumaj+WMheWIhuWPkSAo5ri45oiP6YWN6Z+z57Sg5p2QLCDniYjmnYPljp/lm6ApJyAkWWVsbG93DQpT
>>"%B64%" echo YXkgJyAgICAgICAg6ZyA6KaB55qE6K+d5LuO5Y6f5pW05ZCI5YyF5aSE6I635Y+WLCDmlL7mnKzljIUgdm9pY2UtY2xpcHMvIOWN
>>"%B64%" echo s+WPrycgJFllbGxvdw0KU2F5ICcgIENvc3lWb2ljZSDmqKHlnoso57qmM0dCKSDpnIDmiYvliqjkuIvovb06JyAkWWVsbG93DQpT
>>"%B64%" echo YXkgJyAgICAxLiBodHRwczovL21vZGVsc2NvcGUuY24vbW9kZWxzL2lpYy9Db3N5Vm9pY2UyLTAuNUInDQpTYXkgJyAgICAyLiDo
>>"%B64%" echo p6PljovliLAgRDpcQ29zeVZvaWNlXHByZXRyYWluZWRfbW9kZWxzXCcNClNheSAnICAgIDMuIOWjsOe6v+aWh+S7tuaUviBEOlxD
>>"%B64%" echo b3N5Vm9pY2VcZWx5c2lhLXZvaWNlXGNsaXBzXCcNClNheSAnICDor6bnu4bmraXpqqTop4EgUkVBRE1FLm1kIOesrCAzIOiKgicg
>>"%B64%" echo JFllbGxvdw0KDQojIOiuvue9rum7mOiupOmihOiuvuS4uiBlbHlzaWENCiRzZXR0aW5nc1BhdGggPSBKb2luLVBhdGggJGRzaEhv
>>"%B64%" echo bWUgJ3NldHRpbmdzLnlhbWwnDQppZiAoVGVzdC1QYXRoICRzZXR0aW5nc1BhdGgpIHsNCiAgICAkY29udGVudCA9IEdldC1Db250
>>"%B64%" echo ZW50ICRzZXR0aW5nc1BhdGggLVJhdyAtRW5jb2RpbmcgVVRGOA0KICAgIGlmICgkY29udGVudCAtbm90bWF0Y2ggJ2FnZW50LXBy
>>"%B64%" echo ZXNldHMnKSB7DQogICAgICAgIEFkZC1Db250ZW50ICRzZXR0aW5nc1BhdGggImBuYWdlbnQtcHJlc2V0czpgbiAgZGVmYXVsdDog
>>"%B64%" echo ZWx5c2lhYG4iIC1FbmNvZGluZyBVVEY4DQogICAgICAgIFNheSAnICDlt7Lorr7nva7pu5jorqTpooTorr4gPSBlbHlzaWEnICRH
>>"%B64%" echo cmVlbg0KICAgIH0NCn0NCg0KU2F5ICcnDQpTYXkgJyAg5a6M5oiQISDph43lkK8gRFNIICjlhbPmjonnqpflj6Pph43mlrAgZHNo
>>"%B64%" echo IHdlYiknICRHcmVlbg0KU2F5ICcgIOaWsOS8muivnemAieaLqSBlbHlzaWEg6aKE6K6+IC0+IOeIseiOieWwseWcqOetieS9oOWV
>>"%B64%" echo piEnICRHcmVlbg0KU2F5ICcnDQpSZWFkLUhvc3QgJ+aMieWbnui9puWFs+mXrScNCg==
>>"%B64%" echo -----END CERTIFICATE-----

certutil -decode -f "%B64%" "%PS1%" >nul 2>&1

if not exist "%PS1%" (
    echo Decode failed. Please run as administrator.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" "%~dp0"

del "%B64%" "%PS1%" >nul 2>&1

pause
